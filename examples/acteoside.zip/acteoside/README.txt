The steps to run this example are listed as following:

1. copy necessary files in the working directory
   ./receptor 
   ligand.pdb
   scripts in scripts/ directory
   
2. run scripts
   perl main_entry.pl
   
3. evaluate the results
   examine the sorted results in this file "all_energies.sort"
   